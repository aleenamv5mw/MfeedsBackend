const mongoose = require("mongoose");
const { Schema } = mongoose;

const subscriptionSchema = new Schema({
  accountId: { type: Number, required: true },
  accountName: { type: String, required: true },
  startDate: { type: Date, required: true },
  endDate: { type: Date, required: true },
  subscriptionType: { type: String, required: true },
  status: { type: String, default: "Activated" },
  feeds_Finnish_Renn: { type: Number, required: true },
  feeds_Jobs: { type: Number, required: true },
  feeds_Patent: { type: Number, required: true },
  feeds_Plot: { type: Number, required: true },
  feeds_Sales_Announcement: { type: Number, required: true },
  orderId: { type: Number, required: true },
});

const Subscription = mongoose.model("subscription", subscriptionSchema);

module.exports = Subscription;
