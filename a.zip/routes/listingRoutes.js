const {
  getSearchResults,
  getRSSFeed,
  saverssFeed,
  getSavedRSSFeed,
  updateRSSFeed,
} = require("../controllers/listingController");
const listingController = require("../controllers/listingController.js");

module.exports = async (app, opts) => {
  //fetch listings

  app.get("/api/listings", listingController.fetch);
  app.get("/api/listings/search", getSearchResults);
  app.get("/api/listings/rss", getRSSFeed);
  app.post("/api/listings/rss/:rssId", saverssFeed);
  app.get("/api/listings/rss/saved/:rssId", getSavedRSSFeed);
  app.put("/api/listings/rss/update/:rssId", updateRSSFeed);
};
