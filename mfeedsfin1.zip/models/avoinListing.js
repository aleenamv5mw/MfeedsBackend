const mongoose = require("mongoose");
const listingSchema = new mongoose.Schema({
  date: String,
  address: String,
  time: String,
  companyform: String,
  Title: String,
  //url: String,
  Rekisteröity: String,
  Toimiala: String,
  //buisnessId: String,
});
const avoinListing = mongoose.model("avoinListing", listingSchema);
module.exports = avoinListing;
